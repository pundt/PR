﻿using BL_LZK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_LZK
{
    class Program
    {
        static void Main(string[] args)
        {
            Analyzer analyzer = new Analyzer();


            /// TODO Aufgabe 004 - Aufruf Methode I - (2 Punkte)
            /// Rufen Sie die Methode AddUrl(..) zumindest zwei mal mit beliebigen 
            /// Werten auf. Geben Sie aus ob das Hinzufügen erfolgreich war.



            /// TODO Aufgabe 005 - Aufruf Methode II - (1 Punkt)
            /// Rufen Sie die Methode 'Analyze' des soeben erstellen Analyzer Objekts auf.



        }
    }
}
